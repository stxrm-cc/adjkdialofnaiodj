How to inject the b1g hvh pasterino:

1)Go in a game or at csgo home screen (not suggested, might crash sometimes).
2)Unzip folder at desktop and if needed rename to “stxrmhook”
3)Open terminal and type: cd desktop/stxrmhook
4)After that, copy and paste this: sudo ./Injector csgo_osx64 libvHook.dylib
Should show something like this if you’ve done it right:
“/Users/[User]/Desktop/stxrmhook/libvHook.dylib
module: 0x7BC03060
bootstrapfn: 0xA304DD3
pid: 731
image name: /Users/[User]/Desktop/stxrmhook/bootstrap.dylib
mach_inject: found threadEntry image at: 0x10a304000 with size: 9944
wrote param with size 46”
5)Enjoy tapping skeeters :^)

=============================================================================

Features that don’t work/available soon:
-Night Mode
-Clantag Changer (Even though everything is good, it somehow fucks up)
-FakeLag - Works sometimes (Literally doesn’t work perfectly on any mac cheat)
-Skin Changer - Sorry but after new halloween update this managed to fuck up somehow, fixing s00n.
-AA Indicators - Also everything is good but fucks up all the time
-Auto Zeus - Doesn’t “auto” all the time, but if you’re close enough to a player and click anywhere, it will taze him.

=============================================================================

**CHEAT IS STILL IN BETA SO DON’T COMPLAIN, BEING WORKED ON EVERY DAY. YOU WILL BE SENT THE NEW DYLIB (TILL I FIX THE LOADER) IN EVERY UPDATE, VIA DISCORD OR E-MAIL, -LEAVE YOUR DISCORD AT BUY MESSAGE-, THANKS.**